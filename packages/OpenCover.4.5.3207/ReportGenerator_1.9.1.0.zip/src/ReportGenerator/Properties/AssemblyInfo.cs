﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// Allgemeine Informationen über eine Assembly werden über die folgenden 
// Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
// die mit einer Assembly verknüpft sind.
[assembly: AssemblyTitle("ReportGenerator")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Palmmedia")]
[assembly: AssemblyProduct("ReportGenerator")]
[assembly: AssemblyCopyright("Copyright © Palmmedia 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Durch Festlegen von ComVisible auf "false" werden die Typen in dieser Assembly unsichtbar 
// für COM-Komponenten. Wenn Sie auf einen Typ in dieser Assembly von 
// COM zugreifen müssen, legen Sie das ComVisible-Attribut für diesen Typ auf "true" fest.
[assembly: ComVisible(false)]

// Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
[assembly: Guid("194b5145-bef2-4414-8dcf-2045075bae2d")]

// Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
//
//      Hauptversion
//      Nebenversion 
//      Buildnummer
//      Revision
//
// Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
// übernehmen, indem Sie "*" eingeben:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.9.1.0")]
[assembly: AssemblyFileVersion("1.9.1.0")]
[assembly: NeutralResourcesLanguageAttribute("en-US")]

[assembly: CLSCompliant(true)]
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("ReportGeneratorTest")]

// [assembly: System.Runtime.CompilerServices.InternalsVisibleTo("ReportGeneratorTest, PublicKey=0024000004800000940000000602000000240000525341310004000001000100B91139722596358820A6E216832C62846EE9055F7A275A977A0F7D117930CB51578CC8B9F450AA43435AA4B170C69E0187349FD27BF8548259FFA3C96C39D20356FAF83191BD3CFBAE11F6CB80537572D12432F176AC3E0019FFA3E0E45C7A1E28206AE1B394054C8C930752AB035199573008C283B7E44BFA61EE80DE0971B5")]