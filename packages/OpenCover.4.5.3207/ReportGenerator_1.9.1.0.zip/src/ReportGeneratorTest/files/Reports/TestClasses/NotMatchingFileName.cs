﻿
namespace Test
{
    public class SomeClass
    {
        public string Property1 { get; set; }
    }
}
